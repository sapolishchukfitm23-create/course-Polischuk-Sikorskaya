import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Plus, Trash2, ChevronLeft, CheckCircle, XCircle,
  AlertTriangle, LogIn, Link2, MousePointer, ZoomIn, ZoomOut,
  Maximize2, Save,
} from 'lucide-react';
import { Navbar } from '../components/layout/Navbar';
import { Button, Spinner, Textarea, Input } from '../components/ui';
import { useAuth } from '../lib/auth';
import { api } from '../lib/api';
import type { Story, Node, Edge, ValidationResult } from '../lib/types';

/* ── position helpers ──────────────────────────────────────────────────────── */
interface Pos { x: number; y: number }
const NODE_W = 200;
const NODE_H = 90;

function loadPositions(storyId: string): Record<string, Pos> {
  try { return JSON.parse(localStorage.getItem(`pos:${storyId}`) || '{}'); }
  catch { return {}; }
}
function savePositions(storyId: string, pos: Record<string, Pos>) {
  localStorage.setItem(`pos:${storyId}`, JSON.stringify(pos));
}
function defaultPos(index: number): Pos {
  return { x: 60 + (index % 4) * 280, y: 60 + Math.floor(index / 4) * 180 };
}

/* ── SVG curve helper ──────────────────────────────────────────────────────── */
function edgePath(from: Pos, to: Pos): string {
  const fx = from.x + NODE_W / 2, fy = from.y + NODE_H / 2;
  const tx = to.x + NODE_W / 2, ty = to.y + NODE_H / 2;
  const dx = (tx - fx) * 0.5;
  return `M ${fx} ${fy} C ${fx + dx} ${fy}, ${tx - dx} ${ty}, ${tx} ${ty}`;
}

/* ── component ─────────────────────────────────────────────────────────────── */
export function StudioPage({ storyId }: { storyId: string }) {
  const { user } = useAuth();
  const [story, setStory] = useState<Story | null>(null);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [loading, setLoading] = useState(true);

  const [positions, setPositions] = useState<Record<string, Pos>>({});
  const [pan, setPan] = useState<Pos>({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const svgRef = useRef<SVGSVGElement>(null);

  const [mode, setMode] = useState<'select' | 'connect'>('select');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // edit form
  const [editNode, setEditNode] = useState<Node | null>(null);
  const [editText, setEditText] = useState('');
  const [editImage, setEditImage] = useState('');
  const [editIsStart, setEditIsStart] = useState(false);
  const [editIsEnd, setEditIsEnd] = useState(false);
  const [saving, setSaving] = useState(false);

  // drag / pan refs
  const dragRef = useRef<{ id: string; ox: number; oy: number } | null>(null);
  const panRef = useRef<{ sx: number; sy: number; px: number; py: number } | null>(null);
  const posRef = useRef(positions);
  useEffect(() => { posRef.current = positions; }, [positions]);

  // edge drawing
  const [connectFrom, setConnectFrom] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState<Pos>({ x: 0, y: 0 });
  const [pendingEdge, setPendingEdge] = useState<{ from: string; to: string } | null>(null);
  const [edgeLabel, setEdgeLabel] = useState('');

  // validation
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [validating, setValidating] = useState(false);

  /* load */
  const loadData = useCallback(async () => {
    const [storyData, nodesData, edgesData] = await Promise.all([
      api.getStory(storyId), api.getNodes(storyId), api.getEdges(storyId),
    ]);
    setStory(storyData);
    const ns: Node[] = Array.isArray(nodesData) ? nodesData : [];
    const es: Edge[] = Array.isArray(edgesData) ? edgesData : [];
    setNodes(ns); setEdges(es);
    const stored = loadPositions(storyId);
    const merged: Record<string, Pos> = {};
    ns.forEach((n, i) => { merged[n.id] = stored[n.id] ?? defaultPos(i); });
    setPositions(merged);
    setLoading(false);
  }, [storyId]);
  useEffect(() => { loadData(); }, [loadData]);

  /* helpers */
  const svgPoint = (clientX: number, clientY: number): Pos => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, y: 0 };
    return { x: (clientX - rect.left - pan.x) / zoom, y: (clientY - rect.top - pan.y) / zoom };
  };

  /* pointer events */
  const onNodePointerDown = (e: React.PointerEvent, id: string) => {
    e.stopPropagation();
    if (mode === 'connect') {
      if (!connectFrom) { setConnectFrom(id); return; }
      if (connectFrom !== id) {
        setPendingEdge({ from: connectFrom, to: id });
        setConnectFrom(null); setEdgeLabel('');
      }
      return;
    }
    const node = nodes.find(n => n.id === id)!;
    setSelectedId(id); setEditNode(node);
    setEditText(node.text_content); setEditImage(node.image_url || '');
    setEditIsStart(node.is_start_node); setEditIsEnd(node.is_end_node);
    const pos = posRef.current[id] ?? { x: 0, y: 0 };
    const pt = svgPoint(e.clientX, e.clientY);
    dragRef.current = { id, ox: pt.x - pos.x, oy: pt.y - pos.y };
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const onSvgPointerDown = (e: React.PointerEvent) => {
    if (mode === 'connect') return;
    const tag = (e.target as SVGElement).tagName;
    if (tag === 'svg' || tag === 'rect' && !(e.target as SVGElement).closest('g[data-node]')) {
      setSelectedId(null); setEditNode(null); setConnectFrom(null);
      panRef.current = { sx: e.clientX, sy: e.clientY, px: pan.x, py: pan.y };
      (e.target as Element).setPointerCapture(e.pointerId);
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const svgPt = svgPoint(e.clientX, e.clientY);
    setMousePos(svgPt);
    if (dragRef.current) {
      const { id, ox, oy } = dragRef.current;
      const newPos = { x: svgPt.x - ox, y: svgPt.y - oy };
      setPositions(prev => ({ ...prev, [id]: newPos }));
      return;
    }
    if (panRef.current) {
      const { sx, sy, px, py } = panRef.current;
      setPan({ x: px + e.clientX - sx, y: py + e.clientY - sy });
    }
  };

  const onPointerUp = () => {
    if (dragRef.current) { savePositions(storyId, posRef.current); dragRef.current = null; }
    panRef.current = null;
  };

  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    setZoom(z => Math.max(0.3, Math.min(2.5, z * (e.deltaY > 0 ? 0.9 : 1.1))));
  };

  /* node CRUD */
  const handleAddNode = async () => {
    const rect = svgRef.current?.getBoundingClientRect();
    const cx = rect ? (rect.width / 2 - pan.x) / zoom : 100;
    const cy = rect ? (rect.height / 2 - pan.y) / zoom : 100;
    const result = await api.createNode(storyId, { text_content: 'Нова сцена', image_url: '', is_start_node: false, is_end_node: false });
    if (result.id) {
      setNodes(prev => [...prev, result]);
      setPositions(prev => {
        const updated = { ...prev, [result.id]: { x: cx - NODE_W / 2, y: cy - NODE_H / 2 } };
        savePositions(storyId, updated);
        return updated;
      });
      setSelectedId(result.id); setEditNode(result);
      setEditText(result.text_content); setEditImage('');
      setEditIsStart(false); setEditIsEnd(false);
    }
  };

  const handleSaveNode = async () => {
    if (!editNode || !editText.trim()) return;
    setSaving(true);
    const result = await api.updateNode(editNode.id, {
      text_content: editText.trim(), image_url: editImage.trim(),
      is_start_node: editIsStart, is_end_node: editIsEnd,
    });
    if (result.id) { setNodes(prev => prev.map(n => n.id === result.id ? result : n)); setEditNode(result); }
    setSaving(false);
  };

  const handleDeleteNode = async (id: string) => {
    if (!confirm('Видалити сцену разом із усіма її переходами?')) return;
    await api.deleteNode(id);
    setNodes(prev => prev.filter(n => n.id !== id));
    setEdges(prev => prev.filter(e => e.from_node_id !== id && e.to_node_id !== id));
    if (selectedId === id) { setSelectedId(null); setEditNode(null); }
    setPositions(prev => { const { [id]: _, ...rest } = prev; savePositions(storyId, rest); return rest; });
  };

  /* edge CRUD */
  const handleConfirmEdge = async () => {
    if (!pendingEdge || !edgeLabel.trim()) return;
    const result = await api.createEdge({ from_node_id: pendingEdge.from, to_node_id: pendingEdge.to, choice_text: edgeLabel.trim() });
    if (result.id) { setEdges(prev => [...prev, result]); }
    setPendingEdge(null); setEdgeLabel(''); setMode('select');
  };

  const handleDeleteEdge = async (id: string) => {
    await api.deleteEdge(id);
    setEdges(prev => prev.filter(e => e.id !== id));
  };

  /* fit view */
  const fitView = () => {
    const pts = Object.values(positions);
    if (!pts.length || !svgRef.current) return;
    const { width, height } = svgRef.current.getBoundingClientRect();
    const minX = Math.min(...pts.map(p => p.x));
    const minY = Math.min(...pts.map(p => p.y));
    const maxX = Math.max(...pts.map(p => p.x + NODE_W));
    const maxY = Math.max(...pts.map(p => p.y + NODE_H));
    const z = Math.min(1.5, Math.min(width / (maxX - minX + 80), height / (maxY - minY + 80)));
    setZoom(z);
    setPan({ x: (width - (maxX - minX) * z) / 2 - minX * z + 40 * z, y: (height - (maxY - minY) * z) / 2 - minY * z + 40 * z });
  };

  /* validate */
  const handleValidate = async () => {
    setValidating(true);
    setValidation(await api.validateStory(storyId) as ValidationResult);
    setValidating(false);
  };

  /* guards */
  if (!user) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="text-center"><LogIn className="w-12 h-12 text-slate-600 mx-auto mb-4" /><p className="text-slate-400">Увійдіть, щоб використовувати студію</p></div>
    </div>
  );
  if (loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <Spinner text="Завантаження квесту..." />
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
      <Navbar />
      <div className="pt-16 flex flex-col flex-1 overflow-hidden">

        {/* top bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-800 bg-slate-950/80 backdrop-blur flex-shrink-0">
          <a href="#/studio" className="text-slate-500 hover:text-slate-300 transition-colors"><ChevronLeft className="w-5 h-5" /></a>
          <div className="flex-1 min-w-0">
            <h1 className="text-white font-semibold text-lg truncate">{story?.title}</h1>
          </div>
          <div className="flex items-center gap-1.5">
            <ToolBtn active={mode === 'select'} onClick={() => { setMode('select'); setConnectFrom(null); }} title="Виділення / переміщення"><MousePointer className="w-4 h-4" /></ToolBtn>
            <ToolBtn active={mode === 'connect'} onClick={() => { setMode('connect'); setSelectedId(null); setEditNode(null); }} title="З'єднати вузли"><Link2 className="w-4 h-4" /></ToolBtn>
            <span className="w-px h-5 bg-slate-700 mx-0.5" />
            <ToolBtn onClick={() => setZoom(z => Math.min(2.5, z * 1.2))} title="Збільшити"><ZoomIn className="w-4 h-4" /></ToolBtn>
            <ToolBtn onClick={() => setZoom(z => Math.max(0.3, z * 0.8))} title="Зменшити"><ZoomOut className="w-4 h-4" /></ToolBtn>
            <ToolBtn onClick={fitView} title="Вмістити все"><Maximize2 className="w-4 h-4" /></ToolBtn>
            <span className="w-px h-5 bg-slate-700 mx-0.5" />
            <Button size="sm" onClick={handleAddNode}><Plus className="w-3.5 h-3.5" />Сцена</Button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">

          {/* left panel */}
          <div className="w-72 flex-shrink-0 border-r border-slate-800 bg-slate-900/60 flex flex-col overflow-y-auto">

            {/* node editor */}
            {editNode ? (
              <div className="p-4 space-y-3 border-b border-slate-800">
                <div className="flex items-center justify-between">
                  <h3 className="text-white font-semibold text-sm">Редагувати сцену</h3>
                  <button onClick={() => handleDeleteNode(editNode.id)} className="text-slate-600 hover:text-red-400 transition-colors p-1"><Trash2 className="w-4 h-4" /></button>
                </div>
                <Textarea label="Текст сцени" value={editText} onChange={e => setEditText(e.target.value)} rows={4} placeholder="Що бачить гравець..." />
                <Input label="URL зображення" value={editImage} onChange={e => setEditImage(e.target.value)} placeholder="https://..." type="url" />
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input type="checkbox" checked={editIsStart} onChange={e => setEditIsStart(e.target.checked)} className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-violet-500" />
                    <span className="text-xs text-slate-300">СТАРТ</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input type="checkbox" checked={editIsEnd} onChange={e => setEditIsEnd(e.target.checked)} className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-violet-500" />
                    <span className="text-xs text-slate-300">КІНЕЦЬ</span>
                  </label>
                </div>
                <Button size="sm" className="w-full" onClick={handleSaveNode} loading={saving}><Save className="w-3.5 h-3.5" />Зберегти</Button>
              </div>
            ) : (
              <div className="p-4 border-b border-slate-800 text-slate-500 text-sm italic">
                {mode === 'connect' ? (connectFrom ? '↖ Клікніть цільову сцену' : '↖ Клікніть вихідну сцену') : 'Клікніть на сцену для редагування'}
              </div>
            )}

            {/* pending edge */}
            {pendingEdge && (
              <div className="p-4 border-b border-slate-800 space-y-3 bg-violet-500/5">
                <h3 className="text-white font-semibold text-sm">Текст вибору</h3>
                <Input label="" value={edgeLabel} onChange={e => setEdgeLabel(e.target.value)} placeholder="Що гравець бачить як варіант..." autoFocus />
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" onClick={() => { setPendingEdge(null); }} className="flex-1">Скасувати</Button>
                  <Button size="sm" onClick={handleConfirmEdge} className="flex-1">Додати</Button>
                </div>
              </div>
            )}

            {/* edge list */}
            <div className="p-4 flex-1">
              <h3 className="text-white font-semibold text-sm mb-3">Переходи <span className="text-slate-500 font-normal">({edges.length})</span></h3>
              <div className="space-y-2">
                {edges.length === 0 && <p className="text-slate-600 text-xs text-center py-4">Переходів немає</p>}
                {edges.map(edge => {
                  const from = nodes.find(n => n.id === edge.from_node_id);
                  const to = nodes.find(n => n.id === edge.to_node_id);
                  return (
                    <div key={edge.id} className="flex items-start gap-2 p-2 rounded-lg bg-slate-800/40 border border-slate-800 text-xs">
                      <div className="flex-1 min-w-0">
                        <p className="text-slate-400 truncate">{from?.text_content.slice(0, 28) ?? '?'}</p>
                        <p className="text-violet-400 font-medium truncate my-0.5">→ {edge.choice_text}</p>
                        <p className="text-slate-400 truncate">{to?.text_content.slice(0, 28) ?? '?'}</p>
                      </div>
                      <button onClick={() => handleDeleteEdge(edge.id)} className="text-slate-600 hover:text-red-400 transition-colors pt-0.5"><Trash2 className="w-3 h-3" /></button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* validate */}
            <div className="p-4 border-t border-slate-800 space-y-3">
              <Button variant="secondary" className="w-full" onClick={handleValidate} loading={validating}>Перевірити граф (DFS)</Button>
              {validation && <ValidationPanel result={validation} />}
            </div>
          </div>

          {/* canvas */}
          <div
            className="flex-1 relative overflow-hidden bg-slate-950"
            style={{ backgroundImage: 'radial-gradient(circle, #334155 1px, transparent 1px)', backgroundSize: `${24 * zoom}px ${24 * zoom}px`, backgroundPosition: `${pan.x}px ${pan.y}px` }}
          >
            {mode === 'connect' && (
              <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10 px-3 py-1.5 rounded-full bg-violet-500/20 border border-violet-500/30 text-violet-300 text-xs font-medium pointer-events-none select-none">
                {connectFrom ? 'Клікніть цільову сцену' : 'Клікніть вихідну сцену'}
              </div>
            )}

            <svg
              ref={svgRef}
              className="absolute inset-0 w-full h-full"
              style={{ cursor: mode === 'connect' ? 'crosshair' : 'default' }}
              onPointerDown={onSvgPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onWheel={onWheel}
            >
              <defs>
                <marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto">
                  <path d="M0,0 L0,6 L8,3 z" fill="#7c3aed" />
                </marker>
                <marker id="arrow-temp" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto">
                  <path d="M0,0 L0,6 L8,3 z" fill="#a78bfa" />
                </marker>
              </defs>

              <g transform={`translate(${pan.x},${pan.y}) scale(${zoom})`}>
                {/* edges */}
                {edges.map(edge => {
                  const fp = positions[edge.from_node_id];
                  const tp = positions[edge.to_node_id];
                  if (!fp || !tp) return null;
                  const mid = { x: (fp.x + tp.x) / 2 + NODE_W / 2, y: (fp.y + tp.y) / 2 + NODE_H / 2 };
                  return (
                    <g key={edge.id}>
                      <path d={edgePath(fp, tp)} fill="none" stroke="#7c3aed" strokeWidth="1.5" markerEnd="url(#arrow)" opacity={0.7} />
                      <rect x={mid.x - 44} y={mid.y - 11} width={88} height={22} rx={5} fill="#1e1b4b" />
                      <text x={mid.x} y={mid.y + 4} textAnchor="middle" fontSize="9" fill="#a78bfa" fontFamily="ui-sans-serif,sans-serif">
                        {edge.choice_text.length > 20 ? edge.choice_text.slice(0, 19) + '…' : edge.choice_text}
                      </text>
                    </g>
                  );
                })}

                {/* temp edge while connecting */}
                {mode === 'connect' && connectFrom && positions[connectFrom] && (
                  <line
                    x1={positions[connectFrom].x + NODE_W / 2} y1={positions[connectFrom].y + NODE_H / 2}
                    x2={mousePos.x} y2={mousePos.y}
                    stroke="#a78bfa" strokeWidth="1.5" strokeDasharray="6 3" opacity={0.6}
                    markerEnd="url(#arrow-temp)"
                  />
                )}

                {/* nodes */}
                {nodes.map(node => {
                  const pos = positions[node.id] ?? { x: 0, y: 0 };
                  const isSel = selectedId === node.id;
                  const isSrc = connectFrom === node.id;
                  const borderColor = node.is_start_node ? '#22c55e' : node.is_end_node ? '#f59e0b' : isSel || isSrc ? '#7c3aed' : '#334155';
                  const bgColor = isSel || isSrc ? '#1e1b4b' : '#0f172a';
                  const hasBadge = node.is_start_node || node.is_end_node;

                  return (
                    <g key={node.id} transform={`translate(${pos.x},${pos.y})`}
                      onPointerDown={e => onNodePointerDown(e, node.id)}
                      style={{ cursor: mode === 'connect' ? 'pointer' : 'grab' }}>
                      <rect x={2} y={3} width={NODE_W} height={NODE_H} rx={10} fill="#000" opacity={0.25} />
                      <rect x={0} y={0} width={NODE_W} height={NODE_H} rx={10} fill={bgColor} stroke={borderColor} strokeWidth={isSel || isSrc ? 2 : 1} />
                      {node.is_start_node && <>
                        <rect x={8} y={6} width={36} height={14} rx={3} fill="#16a34a33" />
                        <text x={26} y={16} textAnchor="middle" fontSize="8" fill="#4ade80" fontFamily="ui-sans-serif,sans-serif" fontWeight="700">СТАРТ</text>
                      </>}
                      {node.is_end_node && <>
                        <rect x={node.is_start_node ? 50 : 8} y={6} width={44} height={14} rx={3} fill="#d9770633" />
                        <text x={(node.is_start_node ? 50 : 8) + 22} y={16} textAnchor="middle" fontSize="8" fill="#fbbf24" fontFamily="ui-sans-serif,sans-serif" fontWeight="700">КІНЕЦЬ</text>
                      </>}
                      <foreignObject x={8} y={hasBadge ? 24 : 10} width={NODE_W - 16} height={hasBadge ? 58 : 72} xmlns="http://www.w3.org/1999/xhtml">
                        <div style={{ fontSize: '11px', color: '#cbd5e1', lineHeight: '1.4', overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 4, WebkitBoxOrient: 'vertical', fontFamily: 'ui-sans-serif,sans-serif', userSelect: 'none' }}>
                          {node.text_content}
                        </div>
                      </foreignObject>
                    </g>
                  );
                })}
              </g>
            </svg>

            <div className="absolute bottom-3 right-3 text-slate-600 text-xs font-mono bg-slate-900/80 px-2 py-1 rounded select-none">
              {Math.round(zoom * 100)}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── sub-components ─────────────────────────────────────────────────────────── */
function ToolBtn({ children, active, onClick, title }: { children: React.ReactNode; active?: boolean; onClick: () => void; title?: string }) {
  return (
    <button onClick={onClick} title={title}
      className={`p-2 rounded-lg transition-colors ${active ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'}`}>
      {children}
    </button>
  );
}

function ValidationPanel({ result }: { result: ValidationResult }) {
  return (
    <div className={`p-3 rounded-xl border text-xs ${result.valid ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
      <div className="flex items-center gap-2 mb-2">
        {result.valid ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <XCircle className="w-3.5 h-3.5 text-red-400" />}
        <span className={`font-semibold ${result.valid ? 'text-emerald-400' : 'text-red-400'}`}>{result.valid ? 'Граф коректний' : 'Знайдено проблеми'}</span>
      </div>
      {result.errors.map((err, i) => <p key={i} className="text-red-400 flex items-start gap-1 mb-1"><XCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />{err}</p>)}
      {result.warnings.map((w, i) => <p key={i} className="text-amber-400 flex items-start gap-1 mb-1"><AlertTriangle className="w-3 h-3 mt-0.5 flex-shrink-0" />{w}</p>)}
      <p className="text-slate-500 mt-2">Досяжних: {result.reachable_count} / {result.total_nodes}</p>
    </div>
  );
}
